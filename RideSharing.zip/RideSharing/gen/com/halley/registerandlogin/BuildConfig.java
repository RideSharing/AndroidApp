/** Automatically generated file. DO NOT MODIFY */
package com.halley.registerandlogin;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}