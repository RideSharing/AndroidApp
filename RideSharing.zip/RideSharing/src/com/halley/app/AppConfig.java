package com.halley.app;

public class AppConfig {
	// Server user login url
	public static String URL_LOGIN = "http://192.168.10.74/RESTFul/v1/login";

	// Server user register url
	public static String URL_REGISTER = "http://192.168.10.74/RESTFul/v1/user";
}
