package com.halley.internetconnection;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class InternetConnection {
	ConnectivityManager cm;
	NetworkInfo ni;
}
